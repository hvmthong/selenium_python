from selenium import webdriver
import time
from selenium.webdriver.common.keys import Keys

driver = webdriver.Chrome(executable_path='C:/Users/ACER/Desktop/selenium/chromedriver.exe')
driver.implicitly_wait(5)
driver.maximize_window()
driver.get("http://google.com")

inputElement = driver.find_element_by_name("q")
inputElement.send_keys("Techbeamers")
inputElement.submit()
time.sleep(5)
elem = driver.find_element_by_partial_link_text("Python")
elem.click()
time.sleep(5)
location = "file://C:/Users/ACER/Desktop/selenium/week3-2.html"
driver.get(location)
email_input = driver.find_element_by_xpath("//form[@id='signUpForm']/input[1]")
email_input.send_keys("ssf")



