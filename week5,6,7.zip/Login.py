import unittest
from selenium import webdriver
from selenium.webdriver.common.by import By


class LoginEmail(unittest.TestCase):
    @classmethod
    def setUp(self):
        self.driver = webdriver.Chrome(executable_path='C:/Users/ACER/Desktop/selenium/chromedriver.exe')
        self.driver.implicitly_wait(30)
        self.driver.maximize_window()
        # navigate to the application home page
        self.driver.get("https://webmail.tma.com.vn/")

    def test_1(self):
        #login
        self.username = self.driver.find_element_by_name("username")
        self.username.send_keys("")
        self.password = self.driver.find_element_by_id("password")
        self.password.send_keys("")
        self.twoFA = self.driver.find_element_by_id("zeta-otp")
        self.twoFA.send_keys("")
        self.driver.find_element_by_id('zetaSubmit').click()

        #create folder
        self.driver.find_element_by_id("DWT39").click()
        self.driver.find_element_by_id("NEW_FOLDER").click()
        self.driver.find_element_by_id("CreateNewFolderDialog_name").send_keys("test")
        self.driver.find_element_by_id("CreateNewFolderDialog_button2").click()

        #send email
        self.driver.find_element_by_id("zb__NEW_MENU").click()
        self.driver.implicitly_wait(5)
        self.driver.find_element_by_id("zv__COMPOSE-1_to_control").send_keys("test-vpgbhlroo@srv1.mail-tester.com")
        self.driver.implicitly_wait(3)
        self.driver.find_element_by_id("zv__COMPOSE-1_subject_control").send_keys("test subject")
        self.driver.implicitly_wait(3)
        self.driver.find_element_by_id("ZmHtmlEditor1_body_ifr").send_keys("test content")
        self.driver.implicitly_wait(3)
        self.driver.find_element_by_id("zb__COMPOSE-1__SEND_MENU").click()
        self.driver.implicitly_wait(5)

        #delete email
        self.driver.find_element_by_id("zti__main_Mail__5").click()
        self.driver.implicitly_wait(3)
        self.driver.find_element_by_xpath("//li[@class='RowDouble RowEven RowEven Row-focused'][@tabindex='0']").click()
        self.driver.implicitly_wait(5)
        self.driver.find_element_by_id("zb__CLV-main__DELETE").click()

        #logout
        self.driver.find_element_by_id("DWT30_dropdown").click()
        self.driver.find_element_by_id("logOff").click()
if __name__ == '__main__':
    unittest.main()
