import unittest
import HtmlTestRunner
import os
from Login import LoginEmail

dir = os.getcwd()

login = unittest.TestLoader().loadTestsFromTestCase(LoginEmail)
test_suite = unittest.TestSuite(login)
# open the report file
outfile = open(dir + "/loginTestReport.html", "w")

# configure HTMLTestRunner options
runner = HtmlTestRunner.HTMLTestRunner(stream=outfile,report_title='Test Report', descriptions='Acceptance Tests')

# run the suite using HTMLTestRunner
runner.run(test_suite)