from selenium import webdriver
from selenium.webdriver.support.select import Select
import time

driver = webdriver.Chrome(executable_path='C:/Users/ACER/Desktop/selenium/chromedriver.exe')
driver.implicitly_wait(30)
driver.maximize_window()
driver.get('https://automationfc.github.io/basic-form/index.html')
s1 = Select(driver.find_element_by_id('job1'))

s1.select_by_visible_text('Unit Testing')

for opt in s1.options:
    print(opt.text)
    s1.select_by_visible_text(opt.text)
    time.sleep(10)