import os

import selenium

from selenium import webdriver
from selenium.webdriver.common.keys import Keys


driver = webdriver.Chrome(executable_path='C:/Users/ACER/Desktop/selenium/chromedriver.exe')
driver.implicitly_wait(30)
driver.maximize_window()
driver.get("http://www.google.com")

search_field = driver.find_element_by_name("q")

search_field.send_keys("Selenium WebDriver Interview questions")
search_field.submit()

lists = driver.find_elements_by_class_name("r")

print("Found " + str(len(lists)) + " searches:")

i = 0
for listitem in lists:
    print(listitem.get_attribute("innerHTML"))
    i = i + 1
    if (i > 10):
        break

driver.quit()
